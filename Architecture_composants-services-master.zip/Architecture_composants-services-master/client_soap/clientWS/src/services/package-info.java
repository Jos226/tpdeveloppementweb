@javax.xml.bind.annotation.XmlSchema(namespace = "http://services/")
package services;
